#include <stdio.h>
#include "xgpio.h"
#include "xil_exception.h"
#include "xscugic.h"
#include "xparameters.h"

#define CHANNEL 1

#define LEDS_DEVICE_ID XPAR_GPIO_1_DEVICE_ID      // GPIO for LEDs
#define BUTTONS_DEVICE_ID XPAR_GPIO_2_DEVICE_ID   // GPIO for Buttons
#define INTC_DEVICE_ID XPAR_SCUGIC_0_DEVICE_ID    // Interrupt Controller ID
#define BUTTONS_INTR_ID XPAR_FABRIC_GPIO_2_VEC_ID // Interrupt ID for Buttons

XGpio led_gpio, button_gpio;
XScuGic InterruptController;
u8 button_flag;
u8 led_state;

// Interrupt Service Routine
void Button_Intr_Handler(void *CallbackRef) {
	button_flag = 1;
	XGpio_InterruptClear(&button_gpio, XGPIO_IR_CH1_MASK);
}

// Initialize Interrupt System
int SetupInterruptSystem(XScuGic *IntcInstancePtr, XGpio *GpioInstancePtr) {
    int status;
    XScuGic_Config *IntcConfig;

    IntcConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
    if (IntcConfig == NULL) return XST_FAILURE;

    status = XScuGic_CfgInitialize(IntcInstancePtr, IntcConfig, IntcConfig->CpuBaseAddress);
    if (status != XST_SUCCESS) return XST_FAILURE;

    status = XScuGic_Connect(IntcInstancePtr, BUTTONS_INTR_ID,
                             (Xil_ExceptionHandler)Button_Intr_Handler, (void *)GpioInstancePtr);
    if (status != XST_SUCCESS) return XST_FAILURE;

    XScuGic_Enable(IntcInstancePtr, BUTTONS_INTR_ID);
    XGpio_InterruptEnable(GpioInstancePtr, XGPIO_IR_CH1_MASK);
    XGpio_InterruptGlobalEnable(GpioInstancePtr);

    Xil_ExceptionInit();
    Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
                                 (Xil_ExceptionHandler)XScuGic_InterruptHandler,
                                 IntcInstancePtr);
    Xil_ExceptionEnable();

    return XST_SUCCESS;
}

int main() {
    int status;
    button_flag = 0;
    led_state = 0x01;

    // Initialize GPIO for LEDs and buttons
    status = XGpio_Initialize(&led_gpio, LEDS_DEVICE_ID);
    if (status != XST_SUCCESS) {
    	xil_printf("LED GPIO initialization failure\r\n");
    	return XST_FAILURE;
    }
    status = XGpio_Initialize(&button_gpio, BUTTONS_DEVICE_ID);
    if (status != XST_SUCCESS) {
    	xil_printf("Button GPIO initialization failure\r\n");
    	return XST_FAILURE;
    }

    // Initialize Interrupt System
    status = SetupInterruptSystem(&InterruptController, &button_gpio);
    if (status != XST_SUCCESS) {
        printf("Interrupt setup failed\n");
        return XST_FAILURE;
    }

    // Set GPIO directions for LEDs and buttons
    XGpio_SetDataDirection(&led_gpio, CHANNEL, 0x0);
    XGpio_SetDataDirection(&button_gpio, CHANNEL, 0xF);


    xil_printf("Press a button to trigger an interrupt and turn on LEDs.\n");

    while (1) {
    	// Check for button interrupt flag
    	if (button_flag) {
    		xil_printf("Interrupt occurred\n");
    		button_flag = 0; // Reset flag
        	XGpio_DiscreteWrite(&led_gpio, CHANNEL, 0x00); // Turn LEDs off
    		usleep(1000000); // Sleep 1 second
    		xil_printf("Interrupt complete\n");
    	}
    	led_state = led_state * 2 % 15; // Causes LED to roll-over shift
    	XGpio_DiscreteWrite(&led_gpio, CHANNEL, led_state); // Set LED
		usleep(250000); // Sleep for 0.25 seconds
    }

    return 0;
}
