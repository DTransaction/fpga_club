//
//#include "xparameters.h"
//#include "xuartps.h"
//#include "xgpio.h"
//#include "xil_printf.h"
//#include "sleep.h"
//
//#define UART_DEVICE_ID  XPAR_XUARTPS_0_DEVICE_ID  // Use UART0 (change to _1 if using UART1)
//#define GPIO_DEVICE_ID  XPAR_AXI_GPIO_0_DEVICE_ID // Update with your AXI GPIO ID
//
//// 1. create instances of uartps and gpio
//
//
//int main() {
//    xil_printf("UART LED Control Started. Send '1', '0', 'A', or 'B' to control LEDs.\n");
//
//    //  Initialize UART
//    XUartPs_Config *Config = XUartPs_LookupConfig(UART_DEVICE_ID);
//    XUartPs_CfgInitialize(&UartPs, Config, Config->BaseAddress);
//
//    // 2. Initialize GPIO and specify direction
//
//
//
//    // 3. Clear UART Buffers Before Use
//
//
//
//    u8 led_state = 0x0;  // Initial LED state (all off)
//
//    while (1) {
//        if (XUartPs_IsReceiveData(UartPs.Config.BaseAddress)) {
//            u8 recv_byte = XUartPs_RecvByte(UartPs.Config.BaseAddress);
//            xil_printf("Received: %c\n", recv_byte);
//
//
//			 // 4. write a switch-case statement to check recv_byte
//			 // and update led_state accordingly
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//            // 5. Update LED State
//
//        }
//    }
//}
