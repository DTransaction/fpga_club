#include "xparameters.h"
#include "xuartps.h"
#include "xgpio.h"
#include "xil_printf.h"
#include "sleep.h"

#define UART_DEVICE_ID  XPAR_XUARTPS_0_DEVICE_ID
#define GPIO_DEVICE_ID  XPAR_AXI_GPIO_0_DEVICE_ID

XUartPs UartPs;
XGpio Gpio;

int main() {
    xil_printf("UART LED Control Started. Send a numeric value (0-255) to control LEDs.\n");
    sleep(1);

    // Initialize UART
    XUartPs_Config *Config = XUartPs_LookupConfig(UART_DEVICE_ID);
    XUartPs_CfgInitialize(&UartPs, Config, Config->BaseAddress);

    // Initialize GPIO
    XGpio_Initialize(&Gpio, GPIO_DEVICE_ID);
    XGpio_SetDataDirection(&Gpio, 1, 0); // Set LEDs as Output

    // Clear UART Buffers Before Use
    XUartPs_SetOptions(&UartPs, XUARTPS_OPTION_RESET_TX);
    XUartPs_SetOptions(&UartPs, XUARTPS_OPTION_RESET_RX);

    u8 led_state = 0x0;  // Initial LED state (all off)

    while (1) {
        if (XUartPs_IsReceiveData(UartPs.Config.BaseAddress)) {
            u8 recv_byte = XUartPs_RecvByte(UartPs.Config.BaseAddress);

            if (recv_byte == 0x0D) continue;
            xil_printf("Received byte: 0x%02X\n", recv_byte);  // Print received byte in hex

            switch(recv_byte) {
            case '0':
            	led_state = 0x00;
            	break;
            case '1':
            	led_state = 0x0F;
            	break;
            case 'A':
            	led_state = 0x0A;
            	break;
            case 'B':
            	for (int i=0; i<5; ++i) {
					XGpio_DiscreteWrite(&Gpio, 1, 0x00);
            		sleep(1);
					XGpio_DiscreteWrite(&Gpio, 1, 0x0F);
					sleep(1);
            	}
            	led_state = 0x00;
            }
            // Write the LED state to GPIO
            XGpio_DiscreteWrite(&Gpio, 1, led_state);
        }
    }
}
