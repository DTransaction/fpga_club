#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xgpio.h"
#include "xparameters.h"

#define CHANNEL 1
#define GPIO_0_ID XPAR_GPIO_0_DEVICE_ID
#define GPIO_1_ID XPAR_GPIO_1_DEVICE_ID
#define GPIO_2_ID XPAR_GPIO_2_DEVICE_ID

XGpio switch_gpio;
XGpio led_gpio;
XGpio button_gpio;

u8 status;
u8 switch_state;

int main()
{
    init_platform();
    xil_printf("Program Started\n");
    xil_printf("If all LEDs turn on, program will terminate\n");

    // Initialize GPIO for switches, LEDs, and buttons
    status = XGpio_Initialize(&switch_gpio, GPIO_0_ID);
    if (status != XST_SUCCESS) {
    	xil_printf("Switch GPIO initialization failure\r\n");
    	return XST_FAILURE;
    }
    status = XGpio_Initialize(&led_gpio, GPIO_1_ID);
    if (status != XST_SUCCESS) {
    	xil_printf("LED GPIO initialization failure\r\n");
    	return XST_FAILURE;
    }

    // Set GPIO directions for switches, LEDs, and buttons
    XGpio_SetDataDirection(&switch_gpio, CHANNEL, 0xF);
    XGpio_SetDataDirection(&led_gpio, CHANNEL, 0x0);

    while (1) {
    	switch_state = XGpio_DiscreteRead(&switch_gpio, CHANNEL);
    	XGpio_DiscreteWrite(&led_gpio, CHANNEL, switch_state);
    	if (switch_state == 0xF) {
        	XGpio_DiscreteWrite(&led_gpio, CHANNEL, 0x0);
            xil_printf("Program terminated\n");
            cleanup_platform();
    		return 0;
    	}
    }
    return 0;
}
